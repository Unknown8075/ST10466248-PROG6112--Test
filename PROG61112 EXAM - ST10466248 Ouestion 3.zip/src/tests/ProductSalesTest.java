package tests;

import org.junit.jupiter.api.*;
import productapp.ProductSales;
import static org.junit.jupiter.api.Assertions.*;

public class ProductSalesTest {

    private ProductSales sales;

    @BeforeEach
    public void setUp() {
        sales = new ProductSales();
    }

    @Test
    public void GetSalesOverLimit_ReturnsNumberOfSales() {
        assertEquals(2, sales.GetSalesOverLimit());
    }

    @Test
    public void GetSalesUnderLimit_ReturnsNumberOfSales() {
        assertEquals(4, sales.GetSalesUnderLimit());
    }
}
