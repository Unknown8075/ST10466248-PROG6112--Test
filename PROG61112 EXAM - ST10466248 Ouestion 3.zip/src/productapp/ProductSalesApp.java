package productapp;

import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.io.*;

public class ProductSalesApp extends JFrame {

    private JTextArea textArea;
    private JLabel lblYearsProcessed;
    private ProductSales sales = new ProductSales();

    public ProductSalesApp() {
        super("Product Sales Application");
        setLayout(new BorderLayout());
        setSize(400, 300);
        setDefaultCloseOperation(EXIT_ON_CLOSE);

        JMenuBar menuBar = new JMenuBar();
        JMenu fileMenu = new JMenu("File");
        JMenuItem exitItem = new JMenuItem("Exit");
        exitItem.addActionListener(e -> System.exit(0));
        fileMenu.add(exitItem);

        JMenu toolsMenu = new JMenu("Tools");
        JMenuItem loadItem = new JMenuItem("Load Product Data");
        JMenuItem saveItem = new JMenuItem("Save Product Data");
        JMenuItem clearItem = new JMenuItem("Clear");
        toolsMenu.add(loadItem);
        toolsMenu.add(saveItem);
        toolsMenu.add(clearItem);

        menuBar.add(fileMenu);
        menuBar.add(toolsMenu);
        setJMenuBar(menuBar);

        JPanel buttonPanel = new JPanel();
        JButton btnLoad = new JButton("Load Product Data");
        JButton btnSave = new JButton("Save Product Data");
        buttonPanel.add(btnLoad);
        buttonPanel.add(btnSave);

        textArea = new JTextArea(8, 25);
        textArea.setEditable(false);
        JScrollPane scrollPane = new JScrollPane(textArea);

        lblYearsProcessed = new JLabel("Years Processed: ");

        JPanel bottomPanel = new JPanel();
        bottomPanel.add(lblYearsProcessed);

        add(buttonPanel, BorderLayout.NORTH);
        add(scrollPane, BorderLayout.CENTER);
        add(bottomPanel, BorderLayout.SOUTH);

        btnLoad.addActionListener(e -> loadData());
        btnSave.addActionListener(e -> saveData());
        loadItem.addActionListener(e -> loadData());
        saveItem.addActionListener(e -> saveData());
        clearItem.addActionListener(e -> clearData());
    }

    private void loadData() {
        int total = sales.GetTotalSales();
        double average = sales.GetAverageSales();
        int over = sales.GetSalesOverLimit();
        int under = sales.GetSalesUnderLimit();
        int years = sales.GetProductsProcessed();

        textArea.setText("Total Sales: " + total + "\n"
                + "Average Sales: " + (int) average + "\n"
                + "Sales over limit: " + over + "\n"
                + "Sales under limit: " + under);
        lblYearsProcessed.setText("Years Processed: " + years);
    }

    private void saveData() {
        try (PrintWriter writer = new PrintWriter(new FileWriter("data.txt"))) {
            writer.println("DATA LOG");
            writer.println("************************");
            writer.println(textArea.getText());
            writer.println("************************");
            JOptionPane.showMessageDialog(this, "Data saved to data.txt successfully!");
        } catch (IOException ex) {
            JOptionPane.showMessageDialog(this, "Error saving data: " + ex.getMessage());
        }
    }

    private void clearData() {
        textArea.setText("");
        lblYearsProcessed.setText("Years Processed: ");
    }

    public static void main(String[] args) {
        SwingUtilities.invokeLater(() -> new ProductSalesApp().setVisible(true));
    }
}
