package productapp;

public class ProductSales implements IProductSales {

    private final int SALES_LIMIT = 500;
    private int[][] productSales = {
        {300, 150, 700},
        {250, 200, 600}
    };

    @Override
    public int[][] GetProductSales() { return productSales; }

    @Override
    public int GetTotalSales() {
        int total = 0;
        for (int[] year : productSales) {
            for (int sale : year) total += sale;
        }
        return total;
    }

    @Override
    public double GetAverageSales() {
        int total = GetTotalSales();
        int count = productSales.length * productSales[0].length;
        return (double) total / count;
    }

    @Override
    public int GetSalesOverLimit() {
        int count = 0;
        for (int[] year : productSales) {
            for (int sale : year) if (sale > SALES_LIMIT) count++;
        }
        return count;
    }

    @Override
    public int GetSalesUnderLimit() {
        int count = 0;
        for (int[] year : productSales) {
            for (int sale : year) if (sale < SALES_LIMIT) count++;
        }
        return count;
    }

    @Override
    public int GetProductsProcessed() {
        return productSales.length;
    }
}
